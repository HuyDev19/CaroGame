# Package init cho common
